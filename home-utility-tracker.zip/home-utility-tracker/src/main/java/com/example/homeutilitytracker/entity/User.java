package com.example.homeutilitytracker.entity;  // Must match your package

import jakarta.persistence.*;
import lombok.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import java.util.Collection;
import java.util.List;

@Entity  // Tells Spring this is a DB table
@Data    // Lombok: Auto-generates getters/setters
@Builder // Lombok: Helps create objects easily
@NoArgsConstructor  // Lombok: Default constructor
@AllArgsConstructor // Lombok: Constructor with all fields
public class User implements UserDetails{
    
    @Id  // Primary Key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment
    private Long id;  

    @Column(nullable = false)  // Column cannot be null
    private String name;  

    @Column(unique = true, nullable = false)  // Email must be unique & not null
    private String email;  

    @Column(nullable = false)  // Password cannot be null
    private String password;  

    @Enumerated(EnumType.STRING)  // Stores enum as String (e.g., "USER")
    private Role role;  

    // Enum for roles (ADMIN, USER)
    public enum Role {
        USER, ADMIN
    }
    
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + role.name()));
    }

    @Override
    public String getUsername() {
        return email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    
    //Lombok ka @Data ise auto implement krna chahiye tha but filhal nahi krra to filhal ye laga diya
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
    
    
}