package com.example.home_utility_tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeUtilityTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
